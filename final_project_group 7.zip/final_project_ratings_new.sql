-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: final_project
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ratings_new`
--

DROP TABLE IF EXISTS `ratings_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ratings_new` (
  `rating_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `album_id` varchar(10) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  PRIMARY KEY (`rating_id`),
  KEY `user id` (`user_id`),
  KEY `album_idx` (`album_id`),
  CONSTRAINT `user id` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratings_new`
--

LOCK TABLES `ratings_new` WRITE;
/*!40000 ALTER TABLE `ratings_new` DISABLE KEYS */;
INSERT INTO `ratings_new` VALUES (1,4,'TBB66',4),(2,4,'TB69',5),(3,4,'JM71',3),(4,4,'BD65',1),(5,5,'NV91',3),(6,5,'KW17',5),(7,5,'RH00',4),(8,6,'BD75',4),(9,6,'TRS72',2),(10,6,'AF67',5),(11,6,'PTR84',1),(12,7,'PTR84',4),(13,7,'TB66',3),(14,7,'LH98',5),(15,8,'MJ82',1),(16,8,'SW76',3),(17,9,'KL15',4),(18,9,'FM77',3),(19,9,'TB66',2),(20,10,'TC79',1),(21,10,'LH98',5),(22,10,'PE88',3),(23,11,'BD65',2),(24,11,'RH00',3),(25,11,'JH71',4),(26,12,'JH71',4),(27,12,'BD75',4),(28,12,'TB69',5),(29,13,'KW17',3),(30,13,'NV91',4),(31,13,'SW76',1),(32,14,'TB66',2),(33,14,'SW76',3),(34,15,'KL15',4),(35,15,'MJ82',3),(36,15,'RH00',3),(37,14,'MG71',5),(38,8,'MG71',2),(39,1,'PTR84',4),(40,1,'TC79',5),(41,1,'BD75',2),(42,2,'BD65',3),(43,2,'JM71',2),(44,2,'MG71',5),(45,3,'PE88',4),(46,3,'SW76',3),(47,3,'NV91',2);
/*!40000 ALTER TABLE `ratings_new` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-04 19:20:18
