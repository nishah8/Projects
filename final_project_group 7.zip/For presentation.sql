-- Presentation details 
-- Run all to show all tables
Use final_project;
Select * from topalbums;
Select * from artist_info;
Select * from album_genre;
Select * from user_info;
Select * from ratings_new;

-- Show how the tables are linked with EER Diagram
-- Show views
Select * from average_ratings;
Select * from view_all_ratings; 

-- Show stored function checking if an artist is from the UK
DELIMITER $$  
CREATE FUNCTION IsUK(  
     location varchar(50) 
)   
RETURNS VARCHAR(20)  
DETERMINISTIC  
BEGIN  
    DECLARE Eligibility VARCHAR(20);  
    IF  location ='U.K.' THEN  
        SET Eligibility = 'Yes';  
    ELSE  
    SET Eligibility = 'No';  
    END IF;  
    RETURN (Eligibility);  
END$$ 
DELIMITER 

SELECT artist_info.artist_name, IsUK(artist_info.location)
FROM artist_info;

-- Show stored procedure for showing Pop albums 
DELIMITER //
CREATE PROCEDURE PopAlbum()
BEGIN
SELECT * FROM album_genre
Join
topalbums
ON
album_genre.album_ID = topalbums.AlbumID
WHERE genre = 'Pop';
END //
    
DELIMITER ;

Call PopAlbum;

-- Prepare an example query with a subquery to demonstrate how to extract data from your DB for analysis
SELECT  * FROM topalbums as Top
JOIN
(SELECT artist_id From artist_info as info
WHERE location = 'U.S.' ) as US_Artist
ON
US_Artist.artist_id = Top.ArtistID
WHERE Top.AlbumID in (SELECT album_ID FROM album_genre
WHERE genre = 'Soul');

-- Prepare an example query with group by and having to demonstrate how to extract data from your DB for analysis
SELECT user_id, 
AVG(rating) AS average_rating
FROM
    ratings_new
GROUP BY
    user_id;

 -- Create a view that uses at least 3-4 base tables; prepare and demonstrate a query that uses the view to produce a logically arranged result set for analysis.
Select * from view_all_ratings; 

SELECT title, AVG(rating) 
FROM view_all_ratings
Group by title; 

Select Distinct title, artist_name
from view_all_ratings
Where rating = 5 and gender = 'F';