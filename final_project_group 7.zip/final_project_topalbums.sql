-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: final_project
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `topalbums`
--

DROP TABLE IF EXISTS `topalbums`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `topalbums` (
  `AlbumID` varchar(6) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `ArtistID` int NOT NULL,
  `ReleaseYear` int DEFAULT NULL,
  `Ranking` int NOT NULL,
  PRIMARY KEY (`AlbumID`),
  KEY `artist` (`ArtistID`),
  CONSTRAINT `artist` FOREIGN KEY (`ArtistID`) REFERENCES `artist_info` (`artist_id`),
  CONSTRAINT `rating` FOREIGN KEY (`AlbumID`) REFERENCES `ratings_new` (`album_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `topalbums`
--

LOCK TABLES `topalbums` WRITE;
/*!40000 ALTER TABLE `topalbums` DISABLE KEYS */;
INSERT INTO `topalbums` VALUES ('AF67','I Never Loved a Man the Way I Love You',12,1967,13),('BD65','Highway 61 Revisited',9,1965,18),('BD75','Blood on the Tracks',9,1975,9),('FM77','Rumours',7,1977,7),('JM71','Blue',3,1971,3),('KL15','To Pimp a Butterfly',17,2015,19),('KW17','My Beautiful Dark Twisted Fantasy',16,2010,17),('LH98','The Miseducation of Lauryn Hill',10,1998,10),('MG71','What\'s Going On',1,1971,1),('MJ82','Thriller',11,1982,12),('NV91','Nevermind',6,1991,6),('PE88','It Takes a Nation of Millions to Hold Us Back',14,1988,15),('PTR84','Purple Rain',8,1984,8),('RH00','Kid A',18,2000,20),('SW76','Songs in the Key of Life',4,1976,4),('TB66','Revolver',5,1966,11),('TB69','Abbey Road',5,1969,5),('TBB66','Pet Sounds',2,1966,2),('TC79','London Calling',15,1979,16),('TRS72','Exile on Main Street',13,1972,14);
/*!40000 ALTER TABLE `topalbums` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-04 19:20:19
